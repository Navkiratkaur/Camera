//actions.js file 
function p2kwiet1296439488886_cameraInMemoryMode_onCapture_seq0(eventobject) {
    return onCaptureInMemoryMode.call(this, eventobject);
}

function p2kwiet1296439488886_cameraPrivateMode_onCapture_seq0(eventobject) {
    return onCapturePrivateMode.call(this, eventobject);
}

function p2kwiet1296439488886_cameraPublicMode_onCapture_seq0(eventobject) {
    return onCapturePublicMode.call(this, eventobject);
}

function p2kwiet1296439488894_cameraBasic_onCapture_seq0(eventobject) {
    return onCapture.call(this, eventobject);
}

function p2kwiet1296439488901_btnAccMode_onClick_seq0(eventobject) {
    frmCamAccessMode.show();
}

function p2kwiet1296439488901_btnBasicCam_onClick_seq0(eventobject) {
    frmCamBasic.show();
}

function p2kwiet1296439488901_btnOrientation_onClick_seq0(eventobject) {
    frmCamOrientation.show();
}

function p2kwiet1296439488901_btnOverlay_onClick_seq0(eventobject) {
    frmCamOverlay.show();
}

function p2kwiet1296439488910_camLandscape_onCapture_seq0(eventobject) {
    return onCaptureLandOrientaion.call(this, eventobject);
}

function p2kwiet1296439488910_camPortrait_onCapture_seq0(eventobject) {
    return onCapturePortOrientaion.call(this, eventobject);
}

function p2kwiet1296439488921_cameraOverlay_onCapture_seq0(eventobject) {
    return onCaptureFrmOverLay.call(this, eventobject);
}

function p2kwiet1296439488938_btnContinue_onClick_seq0(eventobject) {
    frmCamOptions.show();
}