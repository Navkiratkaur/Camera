function AS_Camera_c65e84ae19fb4769a6041cc8aa87e258(eventobject) {
    return onCapturePrivateMode.call(this, eventobject);
}