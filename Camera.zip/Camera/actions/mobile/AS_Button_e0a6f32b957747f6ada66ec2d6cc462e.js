function AS_Button_e0a6f32b957747f6ada66ec2d6cc462e(eventobject) {
    frmCamOrientation.show();
}