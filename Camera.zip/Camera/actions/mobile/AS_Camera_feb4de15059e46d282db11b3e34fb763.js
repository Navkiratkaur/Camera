function AS_Camera_feb4de15059e46d282db11b3e34fb763(eventobject) {
    return onCaptureInMemoryMode.call(this, eventobject);
}