function AS_Button_b7085c94bd7e4b649a6a3feb65371084(eventobject) {
    frmCamBasic.show();
}