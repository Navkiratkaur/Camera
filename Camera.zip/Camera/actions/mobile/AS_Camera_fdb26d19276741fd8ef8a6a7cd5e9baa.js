function AS_Camera_fdb26d19276741fd8ef8a6a7cd5e9baa(eventobject) {
    return onCaptureLandOrientaion.call(this, eventobject);
}