function AS_Camera_aa542fc97ead42209a1f003daaf57475(eventobject) {
    return onCaptureFrmOverLay.call(this, eventobject);
}