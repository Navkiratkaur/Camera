function AS_Camera_c0f3c5a31d5b49ed8b3a643861da1d9c(eventobject) {
    return onCapturePublicMode.call(this, eventobject);
}