function AS_Camera_dbe0370c61e14982a3638914082be8f2(eventobject) {
    return onCapture.call(this, eventobject);
}