function AS_Button_bd6c0a2b00874a038524c31ad0e18372(eventobject) {
    frmCamAccessMode.show();
}