function AS_Camera_f3f805db8158404db6b46a8c5c806409(eventobject) {
    return onCapturePortOrientaion.call(this, eventobject);
}