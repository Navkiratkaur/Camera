function p2kwiet1296439488818_cameraInMemoryMode_onCapture_seq0(eventobject) {
    return onCaptureInMemoryMode.call(this, eventobject);
}