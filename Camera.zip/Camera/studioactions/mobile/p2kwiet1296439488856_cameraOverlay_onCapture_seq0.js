function p2kwiet1296439488856_cameraOverlay_onCapture_seq0(eventobject) {
    return onCaptureFrmOverLay.call(this, eventobject);
}