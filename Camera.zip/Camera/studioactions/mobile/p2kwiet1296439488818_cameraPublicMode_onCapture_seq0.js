function p2kwiet1296439488818_cameraPublicMode_onCapture_seq0(eventobject) {
    return onCapturePublicMode.call(this, eventobject);
}