function p2kwiet1296439488846_camPortrait_onCapture_seq0(eventobject) {
    return onCapturePortOrientaion.call(this, eventobject);
}