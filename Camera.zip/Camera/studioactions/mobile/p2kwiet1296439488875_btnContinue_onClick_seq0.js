function p2kwiet1296439488875_btnContinue_onClick_seq0(eventobject) {
    frmCamOptions.show();
}