function p2kwiet1296439488837_btnOrientation_onClick_seq0(eventobject) {
    frmCamOrientation.show();
}