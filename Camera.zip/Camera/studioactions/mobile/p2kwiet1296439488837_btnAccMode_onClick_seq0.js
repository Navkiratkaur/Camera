function p2kwiet1296439488837_btnAccMode_onClick_seq0(eventobject) {
    frmCamAccessMode.show();
}