function p2kwiet1296439488828_cameraBasic_onCapture_seq0(eventobject) {
    return onCapture.call(this, eventobject);
}