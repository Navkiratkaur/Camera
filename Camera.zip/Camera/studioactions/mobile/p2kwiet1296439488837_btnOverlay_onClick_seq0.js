function p2kwiet1296439488837_btnOverlay_onClick_seq0(eventobject) {
    frmCamOverlay.show();
}