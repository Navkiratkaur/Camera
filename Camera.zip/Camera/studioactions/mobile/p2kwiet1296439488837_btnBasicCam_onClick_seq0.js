function p2kwiet1296439488837_btnBasicCam_onClick_seq0(eventobject) {
    frmCamBasic.show();
}