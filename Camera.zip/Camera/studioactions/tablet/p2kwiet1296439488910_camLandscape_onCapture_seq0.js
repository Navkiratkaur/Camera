function p2kwiet1296439488910_camLandscape_onCapture_seq0(eventobject) {
    return onCaptureLandOrientaion.call(this, eventobject);
}