function p2kwiet1296439488938_btnContinue_onClick_seq0(eventobject) {
    frmCamOptions.show();
}