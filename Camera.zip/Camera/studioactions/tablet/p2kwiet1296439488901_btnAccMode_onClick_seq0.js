function p2kwiet1296439488901_btnAccMode_onClick_seq0(eventobject) {
    frmCamAccessMode.show();
}