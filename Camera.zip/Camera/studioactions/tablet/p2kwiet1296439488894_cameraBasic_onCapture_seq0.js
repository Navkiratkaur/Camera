function p2kwiet1296439488894_cameraBasic_onCapture_seq0(eventobject) {
    return onCapture.call(this, eventobject);
}