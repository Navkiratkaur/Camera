function p2kwiet1296439488901_btnBasicCam_onClick_seq0(eventobject) {
    frmCamBasic.show();
}