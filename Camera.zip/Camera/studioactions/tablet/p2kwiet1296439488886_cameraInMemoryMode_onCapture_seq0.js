function p2kwiet1296439488886_cameraInMemoryMode_onCapture_seq0(eventobject) {
    return onCaptureInMemoryMode.call(this, eventobject);
}