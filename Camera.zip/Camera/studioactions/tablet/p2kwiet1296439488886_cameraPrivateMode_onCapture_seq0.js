function p2kwiet1296439488886_cameraPrivateMode_onCapture_seq0(eventobject) {
    return onCapturePrivateMode.call(this, eventobject);
}