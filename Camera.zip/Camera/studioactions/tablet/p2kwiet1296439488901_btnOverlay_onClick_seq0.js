function p2kwiet1296439488901_btnOverlay_onClick_seq0(eventobject) {
    frmCamOverlay.show();
}